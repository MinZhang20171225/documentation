/*
    action.c -- Action handler

    This module implements the /action handler. It is a simple binding of URIs to C functions.
    This enables a very high performance implementation with easy parsing and decoding of query
    strings and posted data.

    Copyright (c) All Rights Reserved. See details at the end of the file.
 */

/*********************************** Includes *********************************/

#include    "goahead.h"

/************************************ Locals **********************************/

static WebsHash actionTable = -1;            /* Symbol table for actions */

static void gettime(Webs *wp);
static void ledsethandle(Webs *wp);
static void passwdsethandle(Webs *wp);

/************************************* Code ***********************************/
/*
    Process an action request. Returns 1 always to indicate it handled the URL
 */
static bool actionHandler(Webs *wp)
{
    WebsKey     *sp;
    char        actionBuf[ME_GOAHEAD_LIMIT_URI + 1];
    char        *cp, *actionName;
    WebsAction  fn;

    assert(websValid(wp));
    assert(actionTable >= 0);

    /*
        Extract the action name
     */
    scopy(actionBuf, sizeof(actionBuf), wp->path);
    if ((actionName = strchr(&actionBuf[1], '/')) == NULL) {
        websError(wp, HTTP_CODE_NOT_FOUND, "Missing action name");
        return 1;
    }
    actionName++;
    if ((cp = strchr(actionName, '/')) != NULL) {
        *cp = '\0';
    }
    /*
        Lookup the C action function first and then try tcl (no javascript support yet).
     */
    sp = hashLookup(actionTable, actionName);
    if (sp == NULL) {
        websError(wp, HTTP_CODE_NOT_FOUND, "Action %s is not defined", actionName);
    } else {
        fn = (WebsAction) sp->content.value.symbol;
        assert(fn);
        if (fn) {
#if ME_GOAHEAD_LEGACY
            (*((WebsProc) fn))((void*) wp, actionName, wp->query);
#else
            (*fn)((void*) wp);
#endif
        }
    }
    return 1;
}


/*
    Define a function in the "action" map space
 */
PUBLIC int websDefineAction(cchar *name, void *fn)
{
    assert(name && *name);
    assert(fn);

    if (fn == NULL) {
        return -1;
    }
    hashEnter(actionTable, (char*) name, valueSymbol(fn), 0);
    return 0;
}


static void closeAction()
{
    if (actionTable != -1) {
        hashFree(actionTable);
        actionTable = -1;
    }
}


PUBLIC void websActionOpen()
{
    actionTable = hashCreate(WEBS_HASH_INIT);
    websDefineAction("gettime", gettime);
    websDefineAction("led_set", ledsethandle);
    websDefineAction("passwd_set", passwdsethandle);
    websDefineHandler("action", 0, actionHandler, closeAction, 0);
}


#if ME_GOAHEAD_LEGACY
/*
    Don't use these routes. Use websWriteHeaders, websEndHeaders instead.

    Write a webs header. This is a convenience routine to write a common header for an action back to the browser.
 */
PUBLIC void websHeader(Webs *wp)
{
    assert(websValid(wp));

    websWriteHeaders(wp, -1, 0);
    websWriteEndHeaders(wp);
    websWrite(wp, "<html>\n");
}


PUBLIC void websFooter(Webs *wp)
{
    assert(websValid(wp));
    websWrite(wp, "</html>\n");
}
#endif

static int read_dev_data(char *name, char *buffer, int len, int *size)
{
	char file[60]="/sys/devices/w1_bus_master1/28-00000482b508/";
	int fd;
	//int i;

	strcat(file, name);
	//printf("file:%s, len=%d\n", file, len);
	
	fd=open(file, O_RDONLY);
	if(fd<0)
	{
		error("Open %s failed!", name);
		return (-1);
	}
	//printf("Open %s ok!\n", name);

	*size=read(fd, buffer, len);
	if(*size<=0)
	{
		error("Read %s failed! size=%d", name, *size);
		close(fd);
		//printf("closed!\n");
		return (-1);
	}
	//printf("Read %s ok! size=%d\n", name, *size);

	close(fd);
	//printf("close %s ok!\n", name);

	buffer[*size-1]='\0';

	/*if(*size>0)
	{
		buffer[*size]='\0';
		printf("content:%s", buffer);
		for(i=0; i<*size; i++)
		{
			printf("%02x ", buffer[i]);
		}
		printf("\n");
	}*/
	
	return 0;
}

static void gettime(Webs *wp)
{
	char        *date;
	int size,i;
	char buffer[100];    

	assert(websValid(wp));

	if(read_dev_data("w1_slave", buffer, sizeof(buffer), &size)<0)
	{
		//fail #fail
		size=sizeof("fail")-1;
		memcpy(buffer, "fail", size);
	}
	else
	{
		for(i=0; i<size; i++)
		{
			if((buffer[i]=='t') && (buffer[i+1]=='='))
				break;
		}

		if(i==size)	//没有找到
		{
			//don't find  #find
			size=sizeof("find")-1;
			memcpy(buffer, "find", size);
		}
		else
		{
			//t=31625'\0'
			i += 2;
			size = size - i - 1;
			memcpy(buffer, buffer+i, size);			
		}
	}

	buffer[size] = '#';
	size+=1;
	trace(4, "ds18b20:");
	for(i=0; i<size; i++)
	{
		trace(4, "%02x", buffer[i]);
	}

   websSetStatus(wp, 200);

   if ((date = websGetDateString(NULL)) != NULL) {
	  i=strlen(date);
	  trace(4, "i=0x%02x", i);
        websWriteHeaders(wp, 1+i+size, 0);
        websWriteEndHeaders(wp);
	  websWriteBlock(wp, buffer, size);
        websWriteBlock(wp, date, i);
	  websWriteBlock(wp, "#", 1);
        wfree(date);
    }
   else
    {
        websWriteHeaders(wp, 6+size, 0);
        websWriteEndHeaders(wp);
	  websWriteBlock(wp, buffer, size);
	  websWriteBlock(wp, "error#", 6);
    }
    
    websDone(wp);
}

static int write_dev_data(char *name, char *buffer, int len)
{
	char file[35]="/sys/class/leds/led2/";
	int fd,ret;

	strcat(file, name);
	trace(4, "file:%s, len=%d", file, len);
	
	fd=open(file, O_RDWR);
	if(fd<0)
	{
		error("Open %s failed!", name);
		return (-1);
	}
	//printf("Open %s ok!\n", name);

	trace(4, "write:%s", buffer);

	ret=write(fd, buffer, len);
	if(ret<0)
	{
		error("Write %s failed!", name);
		close(fd);
		//printf("closed!\n");
		return (-1);
	}
	//printf("Write %s ok!\n", name);

	close(fd);
	//printf("close %s ok!\n", name);
	
	return 0;
}

/*http://192.168.1.6/action/led_set?ledstate=blink&delayon=500&delayoff=500*/
static void ledsethandle(Webs *wp)
{
	char *tmp;
	int ret;

	assert(websValid(wp));

	tmp=websGetVar(wp, "ledstate", "");
	if(strncmp(tmp, "on", sizeof("on")-1)==0)
	{
		ret=write_dev_data("trigger", "none", sizeof("none")-1);
		if(ret==0)
		{
			ret=write_dev_data("brightness", "1", 1);
		}
	}
	else if(strncmp(tmp, "off", sizeof("off")-1)==0)
	{
		ret=write_dev_data("trigger", "none", sizeof("none")-1);
		if(ret==0)
		{
			ret=write_dev_data("brightness", "0", 1);
		}
	}
	else	//blink
	{
		ret=write_dev_data("trigger", "timer", sizeof("timer")-1);
		if(ret==0)
		{
			tmp=websGetVar(wp, "delayon", "");
			if( (strlen(tmp)==(sizeof("500")-1)) && 
			    (memcmp(tmp, "500", sizeof("500")-1) == 0) )
			{
				// 默认500，500; 不能设置500，否则常亮或常灭
				trace(4, "do not set delay_on");
			}
			else
			{
				ret=write_dev_data("delay_on", tmp, strlen(tmp));
			}
			if(ret==0)
			{
				tmp=websGetVar(wp, "delayoff", "");
				if( (strlen(tmp)==(sizeof("500")-1)) && 
				    (memcmp(tmp, "500", sizeof("500")-1) == 0) )
				{
					trace(4, "do not set delay_off");
				}
				else
				{
					ret=write_dev_data("delay_off", tmp, strlen(tmp));
				}
			}
		}	
	}

	if(ret==0)
	{
		websRedirectByStatus(wp, HTTP_CODE_OK);
	}
	else
	{
		websRedirectByStatus(wp, HTTP_CODE_INTERNAL_SERVER_ERROR);
	}

	//wfree(tmp);
}

static int writePassWord(char *path, char *passwd, char len)
{
	char buf[256];
	char size;
	FILE *fp;
	int ret;
	long offset;

	fp = fopen(path, "r+");
	if(fp == NULL) {
        error("Can't open %s", path);
        return -1;
	}
	
	while(1)
	{
		if(fgets(buf, sizeof(buf), fp) == NULL)
		{
			error("can't find admin");
			ret=-2;
			break;
		}
		//查找正确行
		if(strncmp(buf, "user name=admin", sizeof("user name=admin")-1)==0)
		{
			trace(4, buf);
			size=strlen(buf);
			trace(4, "size=%d", size);
			
			memcpy(buf+25, passwd, len);
			trace(4, buf);
			
			//写入新的密码
			offset=0-size;
			ret=fseek(fp, offset, SEEK_CUR);
			if(ret<0)
			{
				error("fseek failed %d", offset);
				ret=-3;
			}
			else
			{
				fputs(buf, fp);
				ret=0;
			}
			
			break;
		}
	}

	fclose(fp);
	trace(4, "close fp!");

	return ret;
}

static void passwdsethandle(Webs *wp)
{
	char *password, *encodedPassword, *username;
	int ret;

	assert(websValid(wp));

	password=websGetVar(wp, "password", "");
	trace(2, "password:%s", password);

	username = "admin";
	
	//#define ME_GOAHEAD_REALM "example.com"
	encodedPassword = websMD5(sfmt("%s:%s:%s", username, ME_GOAHEAD_REALM, password));
	trace(2, "encodedPassword:%s", encodedPassword);

	//write password in /etc/goahead/auth.txt
	ret = writePassWord("/etc/goahead/auth.txt", encodedPassword, 32);
	if(ret<0)
		websRedirectByStatus(wp, HTTP_CODE_INTERNAL_SERVER_ERROR);
	else
		websRedirectByStatus(wp, HTTP_CODE_OK);

	//wfree(username);
	//wfree(encodedPassword);
}

/*
    @copy   default

    Copyright (c) Embedthis Software. All Rights Reserved.

    This software is distributed under commercial and open source licenses.
    You may use the Embedthis GoAhead open source license or you may acquire
    a commercial license from Embedthis Software. You agree to be fully bound
    by the terms of either license. Consult the LICENSE.md distributed with
    this software for full details and other copyrights.

    Local variables:
    tab-width: 4
    c-basic-offset: 4
    End:
    vim: sw=4 ts=4 expandtab

    @end
 */
