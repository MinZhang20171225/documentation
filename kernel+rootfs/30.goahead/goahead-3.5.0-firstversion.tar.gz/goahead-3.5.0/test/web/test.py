#!/usr/bin/env python

print "Content-type: text/html\n\n"
print "<html>Hello world from Python Land!</html>"
