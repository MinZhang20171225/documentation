javah -o platinum-jni.h -classpath ../bin/platinum.jar com.plutinosoft.platinum.UPnP
