//
//  main.m
//  MediaServerCocoaTest
//
//  Created by Sylvain on 9/14/10.
//  Copyright Plutinosoft LLC 2010. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
